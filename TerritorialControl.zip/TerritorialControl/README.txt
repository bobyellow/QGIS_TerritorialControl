Check out the Homepage for more details: https://github.com/bobyellow/QGIS_TerritorialControl
