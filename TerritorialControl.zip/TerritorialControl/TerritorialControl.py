# -*- coding: utf-8 -*-
"""
/***************************************************************************
 TerritorialControl
                                 A QGIS plugin
 TerritorialControl
                              -------------------
        begin                : 2016-10-12
        git sha              : $Format:%H$
        copyright            : (C) 2016 by Ran Tao
        email                : rtao2@uncc.edu
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt4.QtCore import *
from PyQt4.QtGui import *
# Initialize Qt resources from file resources.py
import resources
# Import the code for the dialog
from TerritorialControl_dialog import TerritorialControlDialog
import os.path
import processing
#import qgis.utils
from qgis.core import *
from qgis.utils import *
import csv

QgsApplication.setPrefixPath("C:/PROGRA~2/QGISES~1/apps/qgis", True)
# second argument to False disables the GUI
#qgs = QgsApplication([], True)

# load providers
#qgs.initQgis()
#print QgsApplication.showSettings()

class TerritorialControl:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'TerritorialControl_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Create the dialog (after translation) and keep reference
        self.dlg = TerritorialControlDialog()

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&TerritorialControl')
        # TODO: We are going to let the user set this up in a future iteration
        self.toolbar = self.iface.addToolBar(u'TerritorialControl')
        self.toolbar.setObjectName(u'TerritorialControl')
        self.dlg.lineEdit.clear()
        #output feature
        self.dlg.lineEdit_2.clear()
        self.dlg.pushButton.clicked.connect(self.select_output_file)
        self.dlg.lineEdit_4.clear()
        self.dlg.pushButton_3.clicked.connect(self.select_extent_file)
        self.dlg.lineEdit_5.clear()
        self.dlg.pushButton_4.clicked.connect(self.select_road_file)
        self.dlg.lineEdit_6.clear()
        self.dlg.pushButton_5.clicked.connect(self.select_artroad_file)
        self.dlg.lineEdit_7.clear()
        self.dlg.pushButton_6.clicked.connect(self.select_railroad_file)
        self.dlg.lineEdit_8.clear()
        self.dlg.pushButton_7.clicked.connect(self.select_enddates_file)
        self.dlg.lineEdit_9.clear()
        self.dlg.pushButton_8.clicked.connect(self.select_hexagon_file)
        self.dlg.lineEdit_10.clear()
        self.dlg.pushButton_9.clicked.connect(self.select_event_file)

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('TerritorialControl', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/TerritorialControl/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'TerritorialControl'),
            callback=self.run,
            parent=self.iface.mainWindow())


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&TerritorialControl'),
                action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar

    def select_output_file(self):
        outputfilename = QFileDialog.getSaveFileName(self.dlg, "Select output file ","", '*.shp')
        self.dlg.lineEdit_2.setText(outputfilename)

    def select_extent_file(self):
        extentfilename = QFileDialog.getOpenFileName(self.dlg, "Select extent file ", "", '*.shp')
        self.dlg.lineEdit_4.setText(extentfilename)

    def select_road_file(self):
        roadfilename = QFileDialog.getOpenFileName(self.dlg, "Select road file ", "", '*.shp')
        self.dlg.lineEdit_5.setText(roadfilename)

    def select_artroad_file(self):
        artroadfilename = QFileDialog.getOpenFileName(self.dlg, "Select artificial road file ", "", '*.shp')
        self.dlg.lineEdit_6.setText(artroadfilename)

    def select_railroad_file(self):
        railroadfilename = QFileDialog.getOpenFileName(self.dlg, "Select artificial road file ", "", '*.shp')
        self.dlg.lineEdit_7.setText(railroadfilename)

    def select_enddates_file(self):
        enddatesfilename = QFileDialog.getOpenFileName(self.dlg, "Select end dates file", "", '*.csv')
        self.dlg.lineEdit_8.setText(enddatesfilename)

    def select_hexagon_file(self):
        hexagonfilename = QFileDialog.getOpenFileName(self.dlg, "Select hexagonal grid cells ", "", '*.shp')
        self.dlg.lineEdit_9.setText(hexagonfilename)

    def select_event_file(self):
        eventfilename = QFileDialog.getOpenFileName(self.dlg, "Select event data file ", "", '*.shp')
        self.dlg.lineEdit_10.setText(eventfilename)

    def run(self):
        """Run method that performs all the real work"""
        #layers = self.iface.legendInterface().layers()

        #clip feature (GED conflict events)
        #clip_layer_list = []
        #for clip_layer in layers:
            #clip_layer_list.append(clip_layer.name())
        #self.dlg.comboBox.addItems(clip_layer_list)

        #comboBox does not work well with large data, so read the rest of input data with lineEdit
        

        
        # show the dialog
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        # See if OK was pressed
        #traveltime = "1"
        traveltime = self.dlg.lineEdit.text()
        traveltimelist = traveltime.split(',')
        CountTraveltime = len(traveltimelist)
        outputfilename = self.dlg.lineEdit_2.text()
        extentfilename = self.dlg.lineEdit_4.text()
        roadfilename = self.dlg.lineEdit_5.text()
        artroadfilename = self.dlg.lineEdit_6.text()
        railroadfilename = self.dlg.lineEdit_7.text()
        enddatesfilename = self.dlg.lineEdit_8.text()
        hexagonfilename = self.dlg.lineEdit_9.text()
        eventfilename = self.dlg.lineEdit_10.text()
        #Get EndData From UI
        #EndDate = self.dlg.lineEdit_3.text()
        
        if result:
            # Do something useful here - delete the line containing pass and
            # substitute with your code.
            
            #Clip & Merge First
            ArtRoadLayer = QgsVectorLayer(artroadfilename, 'Artifical Road Layer', 'ogr')
            RoadLayer = QgsVectorLayer(roadfilename,'Road Layer','ogr')

            if (self.dlg.radioButton.isChecked()):
                RailLayer = QgsVectorLayer(railroadfilename, 'Railway Layer', 'ogr')

            Extentlayer = QgsVectorLayer(extentfilename,'Extentlayer','ogr')
            #get the rectangular extent of the geographic extent
            extent = Extentlayer.extent()
            xmin = extent.xMinimum()
            xmax = extent.xMaximum()
            ymin = extent.yMinimum()
            ymax = extent.yMaximum()

            extent_str = str(xmin)+','+str(xmax)+','+str(ymin)+','+str(ymax)
            #print extent_str

            Hexagonlayer = QgsVectorLayer(hexagonfilename,'Hexagonlayer','ogr')
            

            #outputs_QGISCLIP_1_dir = 'C:\\Users\\rtao2\\.qgis2\\python\\plugins\\Ran\\Results\\outputclip11.shp'
            Clip_ArtRoad=processing.runalg('qgis:clip', ArtRoadLayer,Extentlayer,None)
            Clip_Road=processing.runalg('qgis:clip', RoadLayer,Extentlayer,None)
            Clip_Hexagon=processing.runalg('qgis:clip', Hexagonlayer,Extentlayer,None)
            #Clip_Conflict = processing.runalg('qgis:clip', Conflictlayer,Extentlayer,None)

            Clip_ArtRoad_Vec = Clip_ArtRoad['OUTPUT']
            Clip_Road_Vec = Clip_Road['OUTPUT']
            Clip_Hexagon_Vec = Clip_Hexagon['OUTPUT']
            
            #Merge clipped networks as a single one
            # optional: with railway or not

            if (self.dlg.radioButton.isChecked()):
                Clip_Rail=processing.runalg('qgis:clip', RailLayer,Extentlayer,None)
                Clip_Rail_Vec = Clip_Rail['OUTPUT']
                Merge_ArtRR=processing.runalg('saga:mergelayers', [Clip_ArtRoad_Vec,Clip_Road_Vec,Clip_Rail_Vec],True,True,None)
               
            else:
                Merge_ArtRR=processing.runalg('saga:mergelayers', [Clip_ArtRoad_Vec,Clip_Road_Vec],True,True,None)
                
            Merge_ArtRR_Vec = Merge_ArtRR['MERGED']

            #Break merged roads at the intersections, otherwise the hybrid road network has topological error
            
            #Break_ArtRR = processing.runalg('grass7:v.clean', Merge_ArtRR_Vec,0,0.0,"-3618580.59,-3548905.85,716523.53,770885.14",-1.0,0.0001,None,None)
            Break_ArtRR = processing.runalg('grass7:v.clean', Merge_ArtRR_Vec, 0, 0.0, extent_str, -1.0, 0.0001, None, None)

            Break_ArtRR_Vec = Break_ArtRR['output']

            #Add field TimeCost and calculate it
            #This is the very important field as the movement cost: the time (hour) it takes to move 1km on each road segment
            added = processing.runalg('qgis:addfieldtoattributestable', Break_ArtRR_Vec,'TimeCost',1,10.0,3.0,None)
            calc = processing.runalg('qgis:fieldcalculator', added['OUTPUT_LAYER'],'TimeCost',0,10.0,3.0,False,'if(Speed = 0, 9999, $length /(1000*Speed))',None)

            targetLayer = calc['OUTPUT_LAYER']
            #targetLayer is the hybrid road network

            #clipLayerIndex = self.dlg.comboBox.currentIndex()
            #clipLayer = layers[clipLayerIndex]
            clipLayer = iface.addVectorLayer(eventfilename, "Event Layer", "ogr")


            #clipLayer = QgsVectorLayer(conflictfilename, 'Conflictlayer', 'ogr')
            #GEDlayer = clipLayer
            #processing.runandload("grass7:v.net.iso",targetLayer,clipLayer,1000,2,"1-100000","0.5,1,2","TimeCosts",None,None,False,"-1227201.3784,-841001.6147,-1258010.6378,-862874.2643",-1,0.0001,0,None)
            #processing.runandload("grass7:v.net.iso",targetLayer,clipLayer,1000,2,"1-100000",traveltime,"TimeCosts",None,None,False,"-1227201.3784,-841001.6147,-1258010.6378,-862874.2643",-1,0.0001,0,None)
            #SAlayer = QgsVectorLayer('Linestring?crs=epsg:102023&field=TimeID:string(15)&field=cat:nt', 'SAlayer' , 'C:\\Users\\rtao2\\.qgis2\\python\\plugins\\TerritorialControl\\FinalSB.shp')
            #vpr = SAlayer.dataProvider()
            #fields = [QgsField("cat", QVariant.Int)]
            #writer = QgsVectorFileWriter("C:\\Users\\rtao2\\.qgis2\\python\\plugins\\TerritorialControl\\FinalSB.shp", "CP1250", fields, QGis.WKBPoint, None, "ESRI Shapefile")
            
            #Delete the features whose data are after the user-selected EndDate
            #GEDDP = clipLayer.dataProvider() #It seems that the default layer is the same as QgsVectorLayer....
            #request = QgsFeatureRequest().setFilterExpression('"Date" <= EndDate')
            
            #for f in clipLayer.getFeatures(request):  # if select by date, use request
                #clipLayer.deleteFeature(f.id())
            #GEDDP.deleteFeatures([2])

            #GEDselectDate=processing.runalg('qgis:selectbyattribute',clipLayer ,'Date',5,EndDate)
            #GEDselectDateSave=processing.runalg('qgis:saveselectedfeatures', GEDselectDate['OUTPUT'],None)
            #GEDselectDateVec = GEDselectDateSave['OUTPUT_LAYER']
            #GEDselectDateQgs = QgsVectorLayer(GEDselectDateVec,'GEDselectDateQgs','ogr')

            #for Event in GEDselectDateQgs.getFeatures():
            #SelectedFeatures = clipLayer.getFeatures(request)
            TimeID_from0 = 0
            #Events = processing.features(Layer)
            for Event in clipLayer.getFeatures():

                #TimeID = Event['TimeID']-1
                #Date = Event['Date']      
                    
                #Selected = clipLayer.setSelectedFeatures([TimeID_from0])

                #GEDselectDateQgs.setSelectedFeatures([TimeID_from0])
                #if Event['Date'] > EndDate:
                    #TimeID_from0 = TimeID_from0 +1
                    #break
                #else: 

                clipLayer.setSelectedFeatures([TimeID_from0])
    
                #Selected=processing.runalg('qgis:selectbyattribute', layer,'TimeID',0,TimeID,None)
                
                #layer1 = processing.runalg('qgis:saveselectedfeatures', Selected['OUTPUT'], None)
                
                #processing.runalg("grass7:v.net.iso",targetLayer,clipLayer,1000,2,"1-100000","0.5,1,2","TimeCosts",None,None,False,"-1227201.3784,-841001.6147,-1258010.6378,-862874.2643",-1,0.0001,0,'C:\\Users\\rtao2\\.qgis2\\python\\plugins\\TerritorialControl\\ISBBB.shp')               
                #processing.runandload("grass7:v.net.iso",targetLayer,clipLayer,1000,2,"1-100000","0.5,1,2","TimeCosts",None,None,False,"-1227201.3784,-841001.6147,-1258010.6378,-862874.2643",-1,0.0001,0,None)
                #to use result in memory later, use runalg not runandload
                #IsoLayer = processing.runalg("grass7:v.net.iso",targetLayer,clipLayer,1000,2,"1-100000",traveltime,"TimeCost",None,None,False,"-3618580.59,-3548905.85,716523.53,770885.14",-1,0.0001,0,None)
                #IsoLayer = processing.runalg("grass7:v.net.iso", targetLayer, Event, 1000, 2, "1-100000",
                                             #traveltime, "TimeCost", None, None, False, extent_str, -1, 0.0001, 0, None)

                #IsoLayer = processing.runalg("grass7:v.net.iso", targetLayer, clipLayer, 1000, 2, "1-100000",
                                             #traveltime, "TimeCost", None, None, False,extent_str, -1, 0.0001, 0, None)

                #the snapping distance should change with selected resolution
                IsoLayer = processing.runalg("grass7:v.net.iso", targetLayer, clipLayer, 5000, 2, "1-100000",
                                             traveltime, "TimeCost", None, None, False,extent_str, -1, 0.0001, 0, None)

                #print IsoLayer
                #IsoLayer = processing.runalg("grass7:v.net.iso",targetLayer,clipLayer,1000,2,"1-100000",traveltime,"TimeCosts",None,None,False,"-1227201.3784,-841001.6147,-1258010.6378,-862874.2643",-1,0.0001,0,'C:\\Users\\rtao2\\.qgis2\\python\\plugins\\TerritorialControl\\ISO.shp')
                IsoFeature = IsoLayer['output']#get features from the SA layer in memory
             
                #outputlayer = QgsVectorLayer('C:\\Users\\rtao2\\.qgis2\\python\\plugins\\TerritorialControl\\ISBBB.shp','ISOOO','ogr')
                #outputFeature = outputlayer.getFeatures()
                #Dissolve First
                #outputFeatureDis = outputLayerDis.getFeatures()
               
                IsoFeatureDis=processing.runalg('saga:linedissolve', IsoFeature,'cat','cat','cat',0,None)
                #IsoFeatureDis
                #IsoFeatureDissolved
                IsoFeatureDisFea = IsoFeatureDis['DISSOLVED']
                
                #convert Dissolved feature as QgsVectorLayer
                IsoQgsDis = QgsVectorLayer(IsoFeatureDisFea,'IsoQgsDis','ogr')

                #Delete the largest cat
                IsoDP = IsoQgsDis.dataProvider()
                IsoDP.deleteFeatures([CountTraveltime])

                #Delete the two redundant cat fields as result of dissolve lines
                IsoDP.deleteAttributes([1,2])
                IsoQgsDis.updateFields()

                #Add field of travel time
                #IsoDP.addAttributes([QgsField("TravelTime", QVariant.String)])
                #IsoQgsDis.updateFields()
                #Add field of current GED TimeID
                IsoDP.addAttributes([QgsField("TimeID", QVariant.Int)])
                IsoQgsDis.updateFields()

                #Write attributes of travel time and TimeID
                IsoFe = IsoQgsDis.getFeatures()
                IsoQgsDis.startEditing()
                TimeID = Event['TimeID']
                #TimeID123 = TimeID_from0 
                #TimeID123 = Event.id() + 1
                for feature in IsoFe:
                    #IsoQgsDis.changeAttributeValue(feature.id(), 1, traveltimelist[feature.id()])
                    IsoQgsDis.changeAttributeValue(feature.id(), 1, TimeID)
                IsoQgsDis.commitChanges()
                #IsoQgsDis.updateFields()
                
                #if TimeID_from0 == 0: #the first (earliest) one as the basis
                if TimeID_from0 == 0: #the first (earliest) one as the basis
                    IsoQgsDisAll = IsoQgsDis
                    #IsoQgsDisAll = QgsVectorLayer(IsoQgsDis.source(), IsoQgsDis.name(), IsoQgsDis.providerType())
                    IsoDPAll = IsoQgsDisAll.dataProvider()
                    #print 'create Iso for TimeID = 0'
                #IsoQgsDisAll.startEditing()
                #Add features
                IsoFe = IsoQgsDis.getFeatures()
                IsoQgsDisAll.startEditing()
                if TimeID_from0 > 0:
                    for feature2 in IsoFe:
                        IsoDPAll.addFeatures([feature2])
                        #print 'add feature2'
                        IsoQgsDisAll.updateExtents()
                TimeID_from0 = TimeID_from0 +1
                
            #GEDselectDateQgs.removeSelection()
            clipLayer.removeSelection()

            #Join the GED information with TimeID
            IsoQgsDisAll_GED = processing.runalg('qgis:joinattributestable', IsoQgsDisAll, clipLayer,'TimeID','TimeID',None)
            #IsoQgsDisAll_GED_Vec = IsoQgsDisAll_GED['OUTPUT_LAYER']
            IsoQgsDisAll_Qgs = QgsVectorLayer(IsoQgsDisAll_GED['OUTPUT_LAYER'],'IsoQgsDisAll_Qgs','ogr')
            
            #Specify output file name and directory
            #Url1 = "C:\\Users\\rtao2\\.qgis2\\python\\plugins\\TerritorialControl\\"
            #Url2 = "Added5000.shp"
            #Url2 = "SelectGED.shp"
            #Url = Url1+ Url2
            outputfilename_SAlines = outputfilename[:-4] + "_SAline"+".shp"
            writer = QgsVectorFileWriter.writeAsVectorFormat(IsoQgsDisAll_Qgs,outputfilename_SAlines,"utf-8",None,"ESRI Shapefile")
            #writer = QgsVectorFileWriter.writeAsVectorFormat(GEDselectDateQgs,Url,"utf-8",None,"ESRI Shapefile")
            del writer
            

            #add boolean to determine to run For loop or not
            #where For loop can be inserted to calculate multiple results of different timestamps
            #e.g. the end of each year/quarter/month, create/input List of these dates? however depends on what fields SA lines have...
            #right now only two fields: cat (travel time), and TimeID (need to link with date, e.g. join with GED, then select by comparing event date with needed end date)

            #output names = user defined outputname + str(date)
            
            SAlayer = iface.addVectorLayer(outputfilename_SAlines, "Reachable Road Network", "ogr")

            #Raterozatoion to solve overlap
            #Rasterize SA lines with TimeID, use the maximal TimeID as raster value means to use the latest events to update the previous
            #SAlayer = QgsVectorLayer(Url,'SAlayer','ogr')
            #SAlayer  =  IsoQgsDisAll
            
            if (self.dlg.radioButton_2.isChecked()):
                with open(enddatesfilename, 'rb') as datefile:
                    reader = csv.reader(datefile)
                    enddate_list = list(reader)

                for i in  range(0,len(enddate_list)):
                    enddate = int(enddate_list[i][0])
                    outputfilename_enddate = outputfilename[:-4] + "_" + enddate_list[i][0]+".shp"
                    #Raterozatoion to solve overlap
                    #Rasterize SA lines with TimeID, use the maximal TimeID as raster value means to use the latest events to update the previous
                    #SAlayer = QgsVectorLayer(Url,'SAlayer','ogr')

                    #SAlayer = iface.addVectorLayer(outputfilename_SAlines, "SAlayer", "ogr")
                    it = SAlayer.getFeatures( QgsFeatureRequest().setFilterExpression (' "Date_int" <= \'%s\'  ' %enddate ) )
                    #it = SAlayer.getFeatures( QgsFeatureRequest().setFilterExpression (' "TimeID" <= \'%s\'  ' %enddate ) ) 

                    # Set the selection
                    SAlayer.setSelectedFeatures( [ fea.id() for fea in it ] )
                    
                    SAtoRas = processing.runalg('saga:shapestogrid', SAlayer, 'TimeID', 3, 1, 3,extent_str, 100.0, None)

                    #Polygonize (vectorize) and keep TimeID
                    SAtoRas_raster = SAtoRas['USER_GRID']
                    #SA_RastoPoly = processing.runandload('gdalogr:polygonize', SAtoRas_raster,'TimeID',None)
                    SA_RastoPoly = processing.runalg('gdalogr:polygonize', SAtoRas_raster,'TimeID',None)

                  
                    #Spatial Join with hexagons
                    #SA_RastoPoly_Dis_Vec = SA_RastoPoly_Dis['OUTPUT_LAYER']
                    SA_RastoPoly_Dis_Vec = SA_RastoPoly['OUTPUT']
                    #Hexagon_1km = QgsVectorLayer('Z:\\projects\\Minerva\\Africa\\FinalBuffer\\QGIS\\Angola_testHex1km.shp','SAlayer','ogr')
                    Hexagon_1km = Clip_Hexagon_Vec
                    #Hex_SJ_SA = processing.runandload('qgis:joinattributesbylocation', Hexagon_1km, SA_RastoPoly_Dis_Vec,['intersects'],0.0,0,'sum,mean,min,max,median',0,None)
                    Hex_SJ_SA = processing.runalg('qgis:joinattributesbylocation', Hexagon_1km, SA_RastoPoly_Dis_Vec,['intersects'],0.0,0,'sum,mean,min,max,median',0,None)

                    #Dissolve joined hexagon by TimeID
                    Hex_SJ_SA_Vec = Hex_SJ_SA['OUTPUT']
                    #Hex_TimeID = processing.runandload('gdalogr:dissolvepolygons', Hex_SJ_SA_Vec,'geometry','TimeID',False,False,False,False,False,None,None,None)
                    Hex_TimeID = processing.runalg('gdalogr:dissolvepolygons', Hex_SJ_SA_Vec,'geometry','TimeID',False,False,False,False,False,None,None,None)

                    #Join the GED information with TimeID
                    Hex_Smooth_Vec = Hex_TimeID['OUTPUT_LAYER']
                    
                    #Hex_SA = processing.runalg('qgis:joinattributestable', Hex_Smooth_Vec, clipLayer,'TimeID','TimeID',None)
                    #Hex_SA_Vec = Hex_SA['OUTPUT_LAYER']
                    Hex_SA_Qgs = QgsVectorLayer(Hex_Smooth_Vec,'Hex_SA_Qgs','ogr')

                    # to solve error small territories or territories whose starting point (event location) has been occupied by later territories
                    # use contain_event_or_not to determine to keep or not
                    Hex_SA_Qgs_containGED =    processing.runalg('grass7:v.select',Hex_SA_Qgs,0,clipLayer,2,7,False,extent_str,-1.0,0.0001,0,None)
                    #Hex_SA_Qgs_containGED =    processing.runalg('grass7:v.select',Hex_TimeID,0,clipLayer,2,7,False,extent_str,-1.0,0.0001,0,None)
                    Hex_SA_Qgs_containGED_Vec = Hex_SA_Qgs_containGED['output']
                    
                    #Dissolve joined hexagon by TimeID to form multipart polygons
                    Hex_SA_Qgs_containGED_Dis = processing.runalg('gdalogr:dissolvepolygons', Hex_SA_Qgs_containGED_Vec,'geometry','TimeID',True,False,False,False,False,None,None,None)
                    Hex_SA_Qgs_containGED_Dis_Vec = Hex_SA_Qgs_containGED_Dis['OUTPUT_LAYER']

                    #A much easier way to add field of travel time
                    #processing.load(calc['OUTPUT_LAYER'])
                    add_traveltime = processing.runalg('qgis:addfieldtoattributestable', Hex_SA_Qgs_containGED_Dis_Vec,'TravelTime',1,10.0,2.0,None)
                    add_traveltime_vec = add_traveltime['OUTPUT_LAYER']
                    calc_traveltime = processing.runalg('qgis:fieldcalculator', add_traveltime_vec,'TravelTime',0,10.0,2.0,False,float(traveltime),None)
                
                    #To quickly view the result: type in console: processing.load(calc['OUTPUT_LAYER'])
                    
                    #add area of polygons
                    add_Area = processing.runalg('qgis:addfieldtoattributestable', calc_traveltime['OUTPUT_LAYER'],'Area',1,10.0,2.0,None)
                    calc_Area = processing.runalg('qgis:fieldcalculator', add_Area['OUTPUT_LAYER'],'Area',0,10.0,2.0,False,'$area',None)

                    #Add field of territory-calculation end date
                    add_enddate = processing.runalg('qgis:addfieldtoattributestable', calc_Area['OUTPUT_LAYER'],'TerrDate',0,10.0,0,None)
                    calc_enddate = processing.runalg('qgis:fieldcalculator', add_enddate['OUTPUT_LAYER'],'TerrDate',1,10.0,0,False,enddate,None)

                    SA_calc_Vec = calc_enddate['OUTPUT_LAYER']
                    SA_join = processing.runalg('qgis:joinattributestable', SA_calc_Vec, clipLayer,'TimeID','TimeID',None)
                                        
                    Final_Vec = SA_join['OUTPUT_LAYER']
                    #convert Dissolved feature as QgsVectorLayer
                    Final_Qgs = QgsVectorLayer(Final_Vec,'Final_Qgs','ogr')

                    writer = QgsVectorFileWriter.writeAsVectorFormat(Final_Qgs,outputfilename_enddate,"utf-8",None,"ESRI Shapefile")
                    del writer
                    SAlayer.removeSelection()


            else:
                SAtoRas = processing.runalg('saga:shapestogrid', SAlayer, 'TimeID', 3, 1, 3,extent_str, 100.0, None)

                #Polygonize (vectorize) and keep TimeID
                SAtoRas_raster = SAtoRas['USER_GRID']
                #SA_RastoPoly = processing.runandload('gdalogr:polygonize', SAtoRas_raster,'TimeID',None)
                SA_RastoPoly = processing.runalg('gdalogr:polygonize', SAtoRas_raster,'TimeID',None)
                
                #Spatial Join with hexagons
                #SA_RastoPoly_Dis_Vec = SA_RastoPoly_Dis['OUTPUT_LAYER']
                SA_RastoPoly_Dis_Vec = SA_RastoPoly['OUTPUT']
                #Hexagon_1km = QgsVectorLayer('Z:\\projects\\Minerva\\Africa\\FinalBuffer\\QGIS\\Angola_testHex1km.shp','SAlayer','ogr')
                Hexagon_1km = Clip_Hexagon_Vec
                #Hex_SJ_SA = processing.runandload('qgis:joinattributesbylocation', Hexagon_1km, SA_RastoPoly_Dis_Vec,['intersects'],0.0,0,'sum,mean,min,max,median',0,None)
                Hex_SJ_SA = processing.runalg('qgis:joinattributesbylocation', Hexagon_1km, SA_RastoPoly_Dis_Vec,['intersects'],0.0,0,'sum,mean,min,max,median',0,None)
                

                #Dissolve joined hexagon by TimeID
                Hex_SJ_SA_Vec = Hex_SJ_SA['OUTPUT']
                #Hex_TimeID = processing.runandload('gdalogr:dissolvepolygons', Hex_SJ_SA_Vec,'geometry','TimeID',False,False,False,False,False,None,None,None)
                Hex_TimeID = processing.runalg('gdalogr:dissolvepolygons', Hex_SJ_SA_Vec,'geometry','TimeID',False,False,False,False,False,None,None,None)

                #Join the GED information with TimeID
                Hex_Smooth_Vec = Hex_TimeID['OUTPUT_LAYER']
                
                Hex_SA = processing.runalg('qgis:joinattributestable', Hex_Smooth_Vec, clipLayer,'TimeID','TimeID',None)
                Hex_SA_Vec = Hex_SA['OUTPUT_LAYER']
                Hex_SA_Qgs = QgsVectorLayer(Hex_SA_Vec,'Hex_SA_Qgs','ogr')

                # to solve error small territories or territories whose starting point (event location) has been occupied by later territories
                # use contain_event_or_not to determine to keep or not
                Hex_SA_Qgs_containGED =    processing.runalg('grass7:v.select',Hex_SA_Qgs,0,clipLayer,2,7,False,extent_str,-1.0,0.0001,0,None)
                Hex_SA_Qgs_containGED_Vec = Hex_SA_Qgs_containGED['output']

                #Dissolve joined hexagon by TimeID to form multipart polygons
                Hex_SA_Qgs_containGED_Dis = processing.runalg('gdalogr:dissolvepolygons', Hex_SA_Qgs_containGED_Vec,'geometry','TimeID',True,False,False,False,False,None,None,None)
                Hex_SA_Qgs_containGED_Dis_Vec = Hex_SA_Qgs_containGED_Dis['OUTPUT_LAYER']

                
                #A much easier way to add field of travel time
                #processing.load(calc['OUTPUT_LAYER'])
                add_traveltime = processing.runalg('qgis:addfieldtoattributestable', Hex_SA_Qgs_containGED_Dis_Vec,'TravelTime',1,10.0,2.0,None)
                add_traveltime_vec = add_traveltime['OUTPUT_LAYER']
                calc_traveltime = processing.runalg('qgis:fieldcalculator', add_traveltime_vec,'TravelTime',0,10.0,2.0,False,float(traveltime),None)
                #To quickly view the result: type in console: processing.load(calc['OUTPUT_LAYER'])
                
                #add area of polygons
                add_Area = processing.runalg('qgis:addfieldtoattributestable', calc_traveltime['OUTPUT_LAYER'],'Area',1,10.0,2.0,None)
                calc_Area = processing.runalg('qgis:fieldcalculator', add_Area['OUTPUT_LAYER'],'Area',0,10.0,2.0,False,'$area',None)
                
                Final_Vec = calc_Area['OUTPUT_LAYER']
                #convert Dissolved feature as QgsVectorLayer
                Final_Qgs = QgsVectorLayer(Final_Vec,'Final_Qgs','ogr')

                #Url3 = "Angola_SA_test555.shp"
                #Url_SA = Url1+Url3
                writer = QgsVectorFileWriter.writeAsVectorFormat(Final_Qgs,outputfilename,"utf-8",None,"ESRI Shapefile")
                del writer
            
            
